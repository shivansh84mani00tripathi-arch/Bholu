TRIAL VERSION
Open index.html to see the birthday surprise immediately.
No password or countdown is required.
Your background song and voice message are included.
